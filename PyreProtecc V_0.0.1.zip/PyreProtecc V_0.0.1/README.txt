Installation:
-Simply drag the files into your game directory.
Example : Drive:\SteamLibrary\steamapps\common\DARK SOULS III\Game

Uninstallation:
-Simply delete "D3DCompiler_43" and "PyresNightmareOptions" from your game directory.

Re-shading mod: 
I've included a file called "PyresNightmareOptions", Here you can change the VFX values to your liking. I've noticed my edits looked wildly different from my monitor/TV to another. So here you can tinker around until you find an edit you like. You just change the first three values and to save simply just click "File -> save" or press control + S. 

Summary:
This DLL will stop most dark souls 3 cheaters from crashing your game, Banning you, And various other exploits that is possible in the game. Since the recent issue with having items forced into your inventory I wanted to push this out as fast as I can to save others from being banned due to others malicious intent. If you get a crash or find a flaw please contact me at https://discord.gg/ZWA36YT. I'm still working on a few more issues, As of now animations on the rolling can be funky and I'm looking into this. The Arena should be okay to play in, I haven't ran into any issues while in it however I don't play in Arena very much.



-?Pyre?